import flask
from flask import Flask, redirect, url_for, request, render_template, \
    flash, abort, make_response
app = Flask(__name__)

@app.route('/')
def func_root():
    return render_template('a1.html')

@app.route('/act1', methods=['POST'])
def func_act1():

    req = request.form
    v = req.get('v')
    return render_template('a2.html', v=v)

app.run(host='localhost', port=8088, debug=True)
